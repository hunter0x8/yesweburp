@file:Suppress("unused")

package burp


import yesweburp.YesWeBurp


class BurpExtender : YesWeBurp()