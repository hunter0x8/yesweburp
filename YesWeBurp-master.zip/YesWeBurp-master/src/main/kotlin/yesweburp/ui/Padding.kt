package yesweburp.ui

import java.awt.Insets

class Padding(size: Int) : Insets(size, size, size, size)